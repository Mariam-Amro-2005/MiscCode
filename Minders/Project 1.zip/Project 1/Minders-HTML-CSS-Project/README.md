# Minders HTML & CSS Project

## Overview
This project is part of the Minders frontend development track, where we recreate an existing website using **HTML and CSS**. The goal is to practice structuring web pages, styling with CSS, and improving our understanding of layout techniques.

## Tech Stack
- **HTML** (for structuring the webpage)
- **CSS** (for styling and layout)

## Color Palette
The website uses the following colors:
- **Primary Yellow:** `rgb(255, 204, 0)`
- **Secondary Yellow:** `rgb(242, 193, 0)`
- **White:** `rgb(255, 255, 255)`
- **Black:** `rgb(0, 0, 0)`

## Getting Started
### Prerequisites
- A code editor like **VS Code** or **Sublime Text**
- A web browser (Chrome, Firefox, Edge, etc.)

### Installation
1. **Clone the repository:**
   ```bash
   git clone <repository-url>
   ```
2. **Navigate to the project folder:**
   ```bash
   cd minders-html-css-project
   ```
3. **Open the project in a browser:**
   - Open `index.html` directly in your browser
   - Or use the Live Server extension in VS Code for real-time updates

## Contribution Guidelines
- Follow a **consistent code style** (proper indentation, meaningful class names, etc.)
- Keep CSS and HTML **separate** (avoid inline styles)
- Follow the **existing color palette**
- Ensure **responsiveness** for different screen sizes
- Use **Git for version control** and commit with meaningful messages

## Team Members
- **Mariam Amro Ahmed Fathi Seifeldin** (Project Lead)
- **Zyad**
- **Bahaa**

## License
This project is licensed under the **MIT License**.

---

