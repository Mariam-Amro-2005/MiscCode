function printLog() {
    console.log("word entered");
    let word = document.querySelector("#word");
    console.log(word.value);
}

function fetchData(url) {
    return fetch(url).then(response => {
        if (!response.ok) throw new Error(`Error: ${response.statusText}`);
        return response.json();
    });
}

let audio = null;

function handleResults() {
    const word = document.querySelector("#word").value.trim();
    if (!word) return;

    fetchData(`https://api.dictionaryapi.dev/api/v2/entries/en/${word}`)
        .then(data => {
            const phoneticsDiv = document.querySelector(".phonetics");
            const meaningsDiv = document.querySelector(".meanings");

            // Reset output
            phoneticsDiv.textContent = "";
            meaningsDiv.innerHTML = "";

            let phoneticText = "";
            let audioURL = "";
            const allMeanings = [];

            data.forEach(entry => {
                // Get phonetics
                if (!phoneticText) {
                    phoneticText = entry.phonetic || (entry.phonetics.find(p => p.text) || {}).text || "";
                }

                if (!audioURL) {
                    let audioObj = entry.phonetics.find(p => p.audio);
                    if (audioObj && audioObj.audio) {
                        audioURL = audioObj.audio;
                    }
                }

                // Collect all meanings
                    if (Array.isArray(entry.meanings)) {
                        allMeanings.push(...entry.meanings);
                    }
            });

            // Display phonetics
            phoneticsDiv.textContent = phoneticText ? `Phonetic: ${phoneticText}` : "Phonetic: N/A";

            // Set up audio
            const speakerIcon = document.querySelector(".audio img");
            if (audioURL) {
                audio = new Audio(audioURL.startsWith("https") ? audioURL : "https:" + audioURL);
                speakerIcon.style.opacity = "1";
            } else {
                audio = null;
                speakerIcon.style.opacity = "0.4";
            }

            // Display meanings
            allMeanings.forEach(meaning => {
                const part = document.createElement("h3");
                part.textContent = meaning.partOfSpeech;
                meaningsDiv.appendChild(part);

                meaning.definitions.forEach(def => {
                    const defP = document.createElement("p");
                    defP.textContent = `• ${def.definition}`;
                    meaningsDiv.appendChild(defP);

                    if (def.example) {
                        const ex = document.createElement("blockquote");
                        ex.textContent = `Example: ${def.example}`;
                        meaningsDiv.appendChild(ex);
                    }
                });
            });
        })
        .catch(err => {
            document.querySelector(".phonetics").textContent = "";
            document.querySelector(".meanings").textContent = "Could not find definition. Please try another word.";
            document.querySelector(".audio img").style.opacity = "0.4";
            audio = null;
            console.error(err);
        });
}   

function playAudio() {
    if (audio) {
        audio.play();
    }
}

function handleClick() {
    printLog();
    handleResults();
}

document.addEventListener("DOMContentLoaded", () => {
    document.querySelector(".submit").addEventListener("click", handleClick);
    document.querySelector(".audio").addEventListener("click", playAudio);
});
